package com.gugawag.testes.modelo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContaTeste {

    Conta c1;
    Conta c2;

    @BeforeEach
    private void configuraConta(){
        c1 = new Conta();
        c1.setNumero("10");
        c2 = new Conta();
    }


    @Test
    public void deveAlterarNumeroContaNumeroValido(){
        // Config
        String numeroContaValido = "10";

        // executa
        c1.setNumero(numeroContaValido);

        // teste
        Assertions.assertEquals(numeroContaValido, c1.getNumero());
    }

    @Test
    public void deveComecarContaComSaldoZero() {
        // config
        Conta contaNova = new Conta();

        // teste
        Assertions.assertEquals(0.0, contaNova.getSaldo());
    }

//    @Test
//    public void naoDeveriaMudarSaldoSeValorNegativo(){
//        // config
//        Conta contaSaldoPositivo = new Conta();
//        Double saldoPositivo = 100.0;
//        contaSaldoPositivo.setSaldo(saldoPositivo);
//
//        // executar
//
//        Double valorNegativo = -10.0;
//        contaSaldoPositivo.setSaldo(valorNegativo);
//
//        // teste
//        Assertions.assertEquals(saldoPositivo, contaSaldoPositivo.getSaldo());
//    }
//
//    @Test
//    public void naoDeveriaTerSaldoNegativo(){
//        // config
//        Conta contaSaldoPositivo = new Conta();
//        Double saldoPositivo = 100.0;
//        contaSaldoPositivo.setSaldo(saldoPositivo);
//
//        // executar
//
//        Double valorNegativo = -10.0;
//        contaSaldoPositivo.setSaldo(valorNegativo);
//
//        // teste
//        Assertions.assertTrue(contaSaldoPositivo.getSaldo()>=0);
//    }

    @Test
    public void naoDeveDebitarValorMaiorSaldo() {
        // config
        c1.creditar(100.0);

        // executar

        Assertions.assertThrows(SaldoNegativoInvalidoException.class,
                () -> c1.debitar(200.0));
    }

    @Test
    public void deveDebitarValorIgualSaldo() {
        // config
        c1.creditar(100.0);

        // executar
        try {
            c1.debitar(100.0);
        } catch (SaldoNegativoInvalidoException e) {
            Assertions.fail();
        }

        // teste
        Assertions.assertEquals(0.0, c1.getSaldo());
    }

    @Test
    public void naoDeveCreditarValorNegativo() {

        // config
        c1.creditar(-100.0);

        // teste
        Assertions.assertEquals(0.0, c1.getSaldo());
    }

    @Test
    public void naoDeveDebitarValorNegativo(){

        // config
        c1.creditar(100.0);

        // teste
        Assertions.assertThrows(SaldoNegativoInvalidoException.class,
                () -> c1.debitar(-50.0));
    }
    @Test
    public void naodeveTransferirValorMaiorQue3Digitos() {
        // config
        c1.creditar(10000);
        // executar


        // teste
        Assertions.assertThrows(SaldoNegativoInvalidoException.class,
                () -> c1.transferir(10000, c2));
    }


}
