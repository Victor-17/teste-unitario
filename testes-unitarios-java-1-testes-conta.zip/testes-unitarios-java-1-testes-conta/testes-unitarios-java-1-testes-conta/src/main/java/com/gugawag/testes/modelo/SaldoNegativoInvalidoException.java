package com.gugawag.testes.modelo;

public class SaldoNegativoInvalidoException extends Exception {
}
