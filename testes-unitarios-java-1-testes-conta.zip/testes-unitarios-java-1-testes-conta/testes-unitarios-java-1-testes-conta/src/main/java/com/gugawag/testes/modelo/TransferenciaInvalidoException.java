package com.gugawag.testes.modelo;

public class TransferenciaInvalidoException extends Exception {
}
